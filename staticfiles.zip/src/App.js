import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import Contact from './components/Contact';
import Scholarships from './components/Scholarships';
import JobOpenings from './components/JobOpenings';
import TrainingPrograms from './components/TrainingPrograms';

function App() {
    return (
        <Router>
            <Header />
            <Switch>
                <Route exact path="/" component={Home} />
                <Route path="/training" component={TrainingPrograms} />
                <Route path="/scholarships" component={Scholarships} />
                <Route path="/jobs" component={JobOpenings} />
                <Route path="/contact" component={Contact} />
            </Switch>
            <Footer />
        </Router>
    );
}

export default App;
