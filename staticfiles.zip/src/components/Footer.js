import React from 'react';
import { Typography, Container } from '@mui/material';

const Footer = () => {
    return (
        <footer>
            <Container>
                <Typography variant="body1">
                    &copy; 2023 Youth Employment Platform. All rights reserved.
                </Typography>
            </Container>
        </footer>
    );
}

export default Footer;
