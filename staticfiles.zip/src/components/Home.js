import React from 'react';
import { Container, Typography } from '@mui/material';

const Home = () => {
    return (
        <Container>
            <Typography variant="h4" gutterBottom>Welcome to the Youth Employment Platform</Typography>
            <Typography variant="body1">
                Our platform provides resources for skill assessments, training programs, scholarships, and job openings.
            </Typography>
        </Container>
    );
}

export default Home;
