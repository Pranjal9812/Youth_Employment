import React from 'react';
import { Container, Typography } from '@mui/material';

const JobOpenings = () => {
    return (
        <Container>
            <Typography variant="h4" gutterBottom>Current Job Openings</Typography>
            <Typography variant="body1">
                Explore the latest job openings that match your skills and interests.
            </Typography>
        </Container>
    );
}

export default JobOpenings;
