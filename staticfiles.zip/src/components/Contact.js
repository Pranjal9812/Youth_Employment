import React, { useState } from 'react';
import { Container, Typography, TextField, Button } from '@mui/material';
import axios from 'axios';

const Contact = () => {
    const [formData, setFormData] = useState({ name: '', email: '', message: '' });
    const [responseMessage, setResponseMessage] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8000/contact/', formData)
            .then(response => {
                setResponseMessage(response.data.message);
            })
            .catch(error => {
                setResponseMessage('Something went wrong. Please try again later.');
            });
    };

    return (
        <Container>
            <Typography variant="h4" gutterBottom>Contact Us</Typography>
            <form onSubmit={handleSubmit}>
                <TextField name="name" label="Name" value={formData.name} onChange={handleChange} fullWidth margin="normal" required />
                <TextField name="email" label="Email" value={formData.email} onChange={handleChange} fullWidth margin="normal" required />
                <TextField name="message" label="Message" value={formData.message} onChange={handleChange} fullWidth margin="normal" required multiline rows={4} />
                <Button type="submit" variant="contained" color="primary">Submit</Button>
            </form>
            {responseMessage && <Typography variant="body1" color="error">{responseMessage}</Typography>}
        </Container>
    );
}

export default Contact;
