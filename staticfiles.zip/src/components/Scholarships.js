import React from 'react';
import { Container, Typography } from '@mui/material';

const Scholarships = () => {
    return (
        <Container>
            <Typography variant="h4" gutterBottom>Scholarship Opportunities</Typography>
            <Typography variant="body1">
                Here, you will find a list of available scholarships to support further education and training.
            </Typography>
        </Container>
    );
}

export default Scholarships;
