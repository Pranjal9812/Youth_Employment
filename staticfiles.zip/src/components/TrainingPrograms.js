import React from 'react';
import { Container, Typography } from '@mui/material';

const TrainingPrograms = () => {
    return (
        <Container>
            <Typography variant="h4" gutterBottom>Training Programs</Typography>
            <Typography variant="body1">
                Discover training programs tailored to help you bridge skill gaps and enhance your career prospects.
            </Typography>
        </Container>
    );
}

export default TrainingPrograms;
