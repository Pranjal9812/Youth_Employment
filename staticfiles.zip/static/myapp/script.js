// Example function to show a message
function showMessage() {
    alert("Welcome to the Youth Employment Platform!");
}

// Add event listener for DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page Loaded');
    
    // Call showMessage function
    showMessage();
});
