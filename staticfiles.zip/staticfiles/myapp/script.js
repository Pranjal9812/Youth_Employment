// Basic JavaScript for the site

// Example function to show a message
function showMessage() {
    alert("Welcome to the Youth Employment Platform!");
}

// You can add event listeners or other scripts here
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page Loaded');
});
