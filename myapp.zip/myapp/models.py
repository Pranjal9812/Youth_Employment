from django.db import models
from django.contrib.auth.models import User

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    dob = models.DateField(null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    gender = models.CharField(max_length=10, null=True, blank=True)
    courses = models.TextField(null=True, blank=True)
    skills = models.TextField()
    qualifications = models.TextField()
    experience = models.TextField()
    gpa = models.DecimalField(max_digits=4, decimal_places=2, default=0.0)
    profile_picture = models.ImageField(upload_to='profile_pictures/', null=True, blank=True)
    resume = models.FileField(upload_to='resumes/', null=True, blank=True)
    completed_assessments = models.ManyToManyField('SkillAssessment', blank=True)
    completed_trainings = models.ManyToManyField('TrainingProgram', blank=True)
    completed_scholarships = models.ManyToManyField('Scholarship', blank=True)
    completed_jobs = models.ManyToManyField('JobOpening', blank=True)



class SkillAssessment(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

class Question(models.Model):
    text = models.CharField(max_length=200)
    assessment = models.ForeignKey(SkillAssessment, on_delete=models.CASCADE)

class Answer(models.Model):
    text = models.CharField(max_length=200)
    question = models.OneToOneField(Question, on_delete=models.CASCADE)

class TrainingProgram(models.Model):
    name = models.CharField(max_length=100, default='Default Training Program')  # Add a default value here
    description = models.TextField()

class Scholarship(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    eligibility = models.TextField(default='Eligibility criteria not specified')
    application_deadline = models.DateField(default='2024-12-31')

class JobOpening(models.Model):
    name = models.CharField(max_length=100, default='Default Job Name')
    description = models.TextField()
