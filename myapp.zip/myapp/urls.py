from django.urls import path, include
from .views import UserDetailsView, home, contact, thank_you, dashboard, assessments, take_assessment, training, scholarships, jobs, login_view, logout_view
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', home, name='home'),
    path('contact/', contact, name='contact'),
    path('thank-you/', thank_you, name='thank_you'),
    path('dashboard/', login_required(dashboard), name='dashboard'),
    path('assessments/', login_required(assessments), name='assessments'),
    path('assessments/<int:assessment_id>/', login_required(take_assessment), name='take_assessment'),
    path('training/', login_required(training), name='training'),
    path('scholarships/', login_required(scholarships), name='scholarships'),
    path('jobs/', login_required(jobs), name='jobs'),
    path('user-details/', login_required(UserDetailsView.as_view()), name='user_details'),
    path('update-details/', login_required(UserDetailsView.as_view()), name='update_details'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('accounts/', include('django.contrib.auth.urls')),
]

# Serve static and media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
