from django.contrib import admin
from .models import SkillAssessment, Question, Answer, TrainingProgram, Scholarship, JobOpening, UserProfile

class ScholarshipAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'eligibility', 'application_deadline')
    search_fields = ('name', 'eligibility')

admin.site.register(SkillAssessment)
admin.site.register(Question)
admin.site.register(Answer)
admin.site.register(TrainingProgram)
admin.site.register(Scholarship, ScholarshipAdmin)
admin.site.register(JobOpening)
admin.site.register(UserProfile)
