from django.shortcuts import render, redirect, get_object_or_404
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.views import View
from django.contrib.auth.decorators import login_required
from .models import UserProfile, SkillAssessment, TrainingProgram, Scholarship, JobOpening, Question, Answer

def home(request):
    return render(request, 'myapp/index.html')

def contact(request):
    return render(request, 'myapp/contact.html')

def thank_you(request):
    return render(request, 'myapp/thank_you.html')

@login_required
def dashboard(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    completed_trainings = user_profile.completed_trainings.all()
    completed_scholarships = user_profile.completed_scholarships.all()
    completed_jobs = user_profile.completed_jobs.all()
    return render(request, 'myapp/dashboard.html', {
        'user_profile': user_profile,
        'completed_trainings': completed_trainings,
        'completed_scholarships': completed_scholarships,
        'completed_jobs': completed_jobs,
    })

@login_required
def assessments(request):
    assessments = SkillAssessment.objects.all()
    return render(request, 'myapp/assessments.html', {'assessments': assessments})

@login_required
def take_assessment(request, assessment_id):
    assessment = get_object_or_404(SkillAssessment, id=assessment_id)
    questions = Question.objects.filter(assessment=assessment)
    if request.method == "POST":
        score = 1  # Fixed score
        return render(request, 'myapp/result.html', {
            'assessment': assessment,
            'score': score
        })
    return render(request, 'myapp/take_assessment.html', {'assessment': assessment, 'questions': questions})

@login_required
def training(request):
    training_programs = TrainingProgram.objects.all()
    return render(request, 'myapp/training.html', {'training_programs': training_programs})

@login_required
def scholarships(request):
    scholarships = Scholarship.objects.all()
    return render(request, 'myapp/scholarships.html', {'scholarships': scholarships})

@login_required
def jobs(request):
    job_openings = JobOpening.objects.all()
    return render(request, 'myapp/jobs.html', {'job_openings': job_openings})

def login_view(request):
    return render(request, 'myapp/login.html')

def logout_view(request):
    return redirect('home')

@method_decorator(csrf_protect, name='dispatch')
class UserDetailsView(View):
    def post(self, request):
        name = request.POST.get('name')
        email = request.POST.get('email')
        dob = request.POST.get('dob')
        address = request.POST.get('address')
        gender = request.POST.get('gender')
        courses = request.POST.get('courses')
        skills = request.POST.get('skills')
        qualifications = request.POST.get('qualifications')
        experience = request.POST.get('experience')
        gpa = request.POST.get('gpa')
        profile_picture = request.FILES.get('profile_picture')
        resume = request.FILES.get('resume')

        user_profile, created = UserProfile.objects.update_or_create(
            user=request.user,
            defaults={
                'name': name,
                'email': email,
                'dob': dob,
                'address': address,
                'gender': gender,
                'courses': courses,
                'skills': skills,
                'qualifications': qualifications,
                'experience': experience,
                'gpa': gpa,
                'profile_picture': profile_picture,
                'resume': resume,
            }
        )

        return redirect('dashboard')

    def get(self, request):
        return render(request, 'myapp/user_details.html')
