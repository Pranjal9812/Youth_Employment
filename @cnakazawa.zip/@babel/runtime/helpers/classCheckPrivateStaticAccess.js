var assertClassBrand = require("./assertClassBrand.js");
function _classCheckPrivateStaticAccess(s, a, r) {
  return assertClassBrand(a, s, r);
}
module.exports = _classCheckPrivateStaticAccess, module.exports.__esModule = true, module.exports["default"] = module.exports;