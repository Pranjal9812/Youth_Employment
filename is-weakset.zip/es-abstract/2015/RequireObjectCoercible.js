'use strict';

module.exports = require('es-object-atoms/RequireObjectCoercible');
