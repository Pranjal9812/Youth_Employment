'use strict';

var isInteger = require('../helpers/isInteger');

// https://262.ecma-international.org/6.0/#sec-isinteger

module.exports = function IsInteger(argument) {
	return isInteger(argument);
};
