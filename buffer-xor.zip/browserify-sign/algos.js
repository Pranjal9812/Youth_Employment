'use strict';

module.exports = require('./browser/algorithms.json');
