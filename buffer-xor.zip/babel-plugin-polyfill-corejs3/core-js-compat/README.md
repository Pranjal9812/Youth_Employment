`core-js-compat` exposes some files as JSON, and they cannot be
imported by Node.js ESM files.
This folder proxies `core-js-compat` to ensure that every entry
is CJS and can be safely imported.